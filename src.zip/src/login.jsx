import React from "react";

function login() {
  return <div>login</div>;
}

export default login;
